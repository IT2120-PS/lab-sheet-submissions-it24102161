# Observed counts
observed <- c(120, 95, 85, 100)

# Expected probabilities (equal for all)
expected_prob <- c(0.25, 0.25, 0.25, 0.25)

# Perform chi-squared test
chisq.test(x = observed, p = expected_prob)

